package com.example.demo.boot.mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
class DemoBoot02MysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
